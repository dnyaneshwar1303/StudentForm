// Fetch existing students from local storage
document.addEventListener('DOMContentLoaded', loadStudents);

// Function to load students from local storage
function loadStudents() {
  const students = JSON.parse(localStorage.getItem('students')) || [];
  const studentsTable = document.getElementById('studentsData');
  studentsTable.innerHTML = '';
  students.forEach((student, index) => {
    const row = `
      <tr>
        <td>${student.name}</td>
        <td>${student.studentId}</td>
        <td>${student.email}</td>
        <td>${student.contact}</td>
        <td>
          <button onclick="editStudent(${index})">Edit</button>
          <button onclick="deleteStudent(${index})">Delete</button>
        </td>
      </tr>
    `;
    studentsTable.innerHTML += row;
  });
}

// Add new student record
document.getElementById('student-form').addEventListener('submit', function(e) {
  e.preventDefault();

  const name = document.getElementById('studentName').value;
  const studentId = document.getElementById('studentId').value;
  const email = document.getElementById('studentEmail').value;
  const contact = document.getElementById('contactNumber').value;

  if (!name || !studentId || !email || !contact) {
    alert('All fields are required!');
    return;
  }

  if (isNaN(studentId) || isNaN(contact)) {
    alert('Student ID and Contact Number must be numeric');
    return;
  }

  const student = { name, studentId, email, contact };
  const students = JSON.parse(localStorage.getItem('students')) || [];
  students.push(student);
  localStorage.setItem('students', JSON.stringify(students));

  // Clear form
  document.getElementById('student-form').reset();

  // Reload students list
  loadStudents();
});

// Edit student record
function editStudent(index) {
  const students = JSON.parse(localStorage.getItem('students')) || [];
  const student = students[index];
  
  document.getElementById('studentName').value = student.name;
  document.getElementById('studentId').value = student.studentId;
  document.getElementById('studentEmail').value = student.email;
  document.getElementById('contactNumber').value = student.contact;

  deleteStudent(index);
}

// Delete student record
function deleteStudent(index) {
  const students = JSON.parse(localStorage.getItem('students')) || [];
  students.splice(index, 1);
  localStorage.setItem('students', JSON.stringify(students));
  loadStudents();
}